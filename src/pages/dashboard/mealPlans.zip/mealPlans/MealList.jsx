import React from 'react'

const MealList = () => {
  return (
    <div>MealList</div>
  )
}

export default MealList